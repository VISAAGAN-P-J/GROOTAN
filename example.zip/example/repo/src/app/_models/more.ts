export class more {
   
        address_line1:string;
        address_line2:string;
        address_line3:string;
        phone:number;
    }
