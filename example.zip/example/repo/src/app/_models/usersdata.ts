import { more } from "./more";

export class UserData {
    name: number;
    age: string;
    dob: string;
    firstName: string;
    lastName: string;
    more:more;
}